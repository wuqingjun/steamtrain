#ifndef __SQUARE_H__
#define __SQUARE_H__
//
// draw a square
// 
#ifdef __cplusplus
extern "C" {
#endif

void square(double x, double y, double z, double l, double w, Color color);

#ifdef __cplusplus
}
#endif

#endif // __SQUARE_H__
