#ifndef __CYLINDER_H__
#define __CYLINDER_H__


//
// draw the cylinder. for example the stick holding the bubble.
//
void train(double x, double y, double z, double scaleX, double scaleY, double scaleZ);


#endif //__CYLINDER_H__
