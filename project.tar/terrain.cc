#include "color.h"
#include "diamondsquare.h"
#include "terrain.h" 
#define GL_GLEXT_PROTOTYPES
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


extern float rep;
extern float shinyvec[1];
extern unsigned int texture[20];

const double PI = 3.1415926;

//
// 
//

void terrain(double l, double w, double h)
{
	int M = pow(2, 8) + 1;
	vector<vector<float> > heightmap(M, vector<float>(M, 0.0));
	diamondsquare(heightmap, 0.8, M, 0, 0, M - 1, M - 1); 	
	for(int i = 0; i < M; ++i)
	{
		for(int j = 0; j < M ; ++j)
		{
			
		}
	}
}
