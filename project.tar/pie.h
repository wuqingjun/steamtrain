#ifndef	__PIE_H__ 
#define	__PIE_H__ 
//
// draw a square
// 
#ifdef __cplusplus
extern "C" {
#endif

void pie(double r, Color color);

#ifdef __cplusplus
}
#endif

#endif // __PILE_H__
