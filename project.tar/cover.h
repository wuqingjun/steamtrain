#ifndef __COVER_H__
#define __COVER_H__
//
// draw a square
// 
#ifdef __cplusplus
extern "C" {
#endif


void cover(double r, double angle, double h, Color color);

#ifdef __cplusplus
}
#endif

#endif // __COVER_H_
